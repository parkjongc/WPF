﻿using System;
using System.Collections.Generic;
using System.Configuration;          // ConfigurationManager
using System.Data.SqlClient;        // SqlConnection, SqlCommand
using System.Diagnostics;           // Debug.WriteLine
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;



namespace DanawaR_Host
{
    public static class Server
    {
        private static TcpListener? listener;
        private static readonly List<TcpClient> clients = new();   // 접속 중인 클라 목록
        private const int Port = 9000;

        // 임시 코드 생성용 랜덤 (한 번만 만들고 돌려씀)
        private static readonly Random rand = new();

        // App.config의 connectionStrings["DB"] 사용
        private static readonly string conn =
            ConfigurationManager.ConnectionStrings["DB"].ConnectionString;

        // 앱 시작 시 한 번만 호출
        public static void Start()
        {
            if (listener != null) return;   // 이미 실행 중이면 무시

            listener = new TcpListener(IPAddress.Any, Port); // IPAddress.Any = 0.0.0.0
            listener.Start();
            Debug.WriteLine($"[HOST] Server started on port {Port}");

            _ = AcceptLoop();  // 클라 접속 대기 루프
        }

        // 클라 접속을 계속 받는 루프
        private static async Task AcceptLoop()
        {
            if (listener == null) return;

            while (true)
            {
                var client = await listener.AcceptTcpClientAsync();
                lock (clients) clients.Add(client);
                Debug.WriteLine("[HOST] Client connected");

                // 접속한 클라 수신 루프 시작
                _ = HandleClient(client);

                // 접속 직후 임시 인증 코드 JSON 한 번 보내기
                string code = GenerateTempCode();
                var authMsg = new AuthMessage
                {
                    type = "AUTH_CODE",
                    code = code,
                    expireSec = 300
                };

                await SendJsonAsync(client, authMsg);
                Debug.WriteLine($"[HOST] Sent AUTH_CODE: {code}");
            }
        }

        // 클라 한 명 담당 루프
        private static async Task HandleClient(TcpClient client)
        {
            var stream = client.GetStream();
            var buffer = new byte[1024];

            try
            {
                while (client.Connected)
                {
                    int bytes = await stream.ReadAsync(buffer, 0, buffer.Length);
                    if (bytes <= 0) break;

                    string msg = Encoding.UTF8.GetString(buffer, 0, bytes);
                    Debug.WriteLine("[HOST] Received: " + msg);

                    // 1) JSON → SensorData 변환 시도
                    SensorData? data = null;
                    try
                    {
                        data = JsonSerializer.Deserialize<SensorData>(msg);
                    }
                    catch (Exception ex)
                    {
                        Debug.WriteLine("[HOST] JSON parse error: " + ex.Message);
                    }

                    // 2) 유효한 센서 데이터인 경우에만 DB 저장
                    if (data != null && !string.IsNullOrEmpty(data.DeviceID))
                    {
                        try
                        {
                            SaveToDB(data);
                        }
                        catch (Exception ex)
                        {
                            Debug.WriteLine("[HOST] DB insert error: " + ex.Message);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine("[HOST] HandleClient error: " + ex.Message);
            }
            finally
            {
                lock (clients) clients.Remove(client);
                client.Close();
                Debug.WriteLine("[HOST] Client disconnected");
            }
        }

        // SensorDataLog 테이블에 한 줄 INSERT
        private static void SaveToDB(SensorData d)
        {
            using var con = new SqlConnection(conn);
            con.Open();

            string q = @"
                INSERT INTO SensorDataLog
                (DeviceID, CpuUsage, RamUsagePercent, DiskUsagePercent, 
                 NetworkSent, NetworkReceived, VirtualTemp)
                VALUES
                (@DeviceID, @Cpu, @Ram, @Disk, @NSent, @NRecv, @Temp);
            ";

            using var cmd = new SqlCommand(q, con);
            cmd.Parameters.AddWithValue("@DeviceID", d.DeviceID);
            cmd.Parameters.AddWithValue("@Cpu", d.Cpu);
            cmd.Parameters.AddWithValue("@Ram", d.Ram);
            cmd.Parameters.AddWithValue("@Disk", d.Disk);
            cmd.Parameters.AddWithValue("@NSent", d.NetworkSent);
            cmd.Parameters.AddWithValue("@NRecv", d.NetworkReceived);
            cmd.Parameters.AddWithValue("@Temp", d.Temp);

            cmd.ExecuteNonQuery();
            Debug.WriteLine("[HOST] DB Insert OK");
        }

        // 객체 → JSON 직렬화해서 한 클라에 전송
        private static Task SendJsonAsync(TcpClient client, object payload)
        {
            string json = JsonSerializer.Serialize(payload);
            byte[] data = Encoding.UTF8.GetBytes(json);
            var stream = client.GetStream();

            return stream.WriteAsync(data, 0, data.Length);
        }

        // 6자리 임시코드
        private static string GenerateTempCode()
        {
            // static Random 사용
            lock (rand)   // Random은 스레드 세이프가 아니라서 잠깐 잠궈줌
            {
                return rand.Next(100000, 999999).ToString();
            }
        }

        // “종료 명령 보내기” 버튼에서 호출할 함수
        public static async Task BroadcastShutdownAsync()
        {
            var shutdownMsg = new { type = "SHUTDOWN" };

            List<TcpClient> snapshot;
            lock (clients) snapshot = new List<TcpClient>(clients);

            foreach (var c in snapshot)
            {
                if (!c.Connected) continue;
                await SendJsonAsync(c, shutdownMsg);
            }

            Debug.WriteLine("[HOST] Broadcast SHUTDOWN");
        }
    }

    // AUTH_CODE 구조
    public class AuthMessage
    {
        public string type { get; set; } = "AUTH_CODE";
        public string code { get; set; } = "";
        public int expireSec { get; set; } = 300;
    }

    // Agent → Host로 보내는 센서 데이터 구조
    public class SensorData
    {
        public string DeviceID { get; set; } = "";
        public float Cpu { get; set; }
        public float Ram { get; set; }
        public float Disk { get; set; }
        public float NetworkSent { get; set; }
        public float NetworkReceived { get; set; }
        public float Temp { get; set; }
    }
}
